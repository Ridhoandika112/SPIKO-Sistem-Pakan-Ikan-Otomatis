/*
   SISTEM MONITORING DAN PEMBERI PAKAN IKAN OTOMATIS
   AVR Bare Metal - ATmega2560 / Arduino Mega 2560

   Pin:
   DS18B20 DQ  -> D22 / PA0
   Pot pH      -> A0  / PF0 / ADC0
   DS1307 SDA  -> D20 / PD1
   DS1307 SCL  -> D21 / PD0
   Servo       -> D9  / PH6
*/

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>
#include <stdlib.h>

// =====================================================
// KONFIGURASI PIN
// =====================================================

// DS18B20 pada D22 = PA0
#define DS18B20_DDR   DDRA
#define DS18B20_PORT  PORTA
#define DS18B20_PINR  PINA
#define DS18B20_PIN   PA0

// Servo pada D9 = PH6
#define SERVO_DDR   DDRH
#define SERVO_PORT  PORTH
#define SERVO_PIN   PH6

// DS1307 Address
#define DS1307_ADDR 0x68

// =====================================================
// VARIABEL JADWAL PAKAN
// =====================================================
uint8_t jamPakan1 = 12;
uint8_t menitPakan1 = 40;

uint8_t jamPakan2 = 17;
uint8_t menitPakan2 = 0;

uint8_t sudahPakan1 = 0;
uint8_t sudahPakan2 = 0;

// =====================================================
// DELAY VARIABEL
// =====================================================
void delay_ms_var(uint16_t ms)
{
    while (ms--)
    {
        _delay_ms(1);
    }
}

void delay_us_var(uint16_t us)
{
    while (us--)
    {
        _delay_us(1);
    }
}

// =====================================================
// UART0 SERIAL MONITOR
// =====================================================
void UART0_Init(uint32_t baud)
{
    uint16_t ubrr = (F_CPU / (16UL * baud)) - 1;

    UBRR0H = (uint8_t)(ubrr >> 8);
    UBRR0L = (uint8_t)ubrr;

    UCSR0B = (1 << TXEN0);                    // Enable transmitter
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);   // 8-bit data
}

void UART0_SendChar(char data)
{
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = data;
}

void UART0_SendString(const char *str)
{
    while (*str)
    {
        UART0_SendChar(*str++);
    }
}

void UART0_SendInt(int16_t data)
{
    char buffer[10];
    itoa(data, buffer, 10);
    UART0_SendString(buffer);
}

void UART0_SendFloat(float data, uint8_t width, uint8_t precision)
{
    char buffer[20];
    dtostrf(data, width, precision, buffer);
    UART0_SendString(buffer);
}

// =====================================================
// ADC UNTUK PH SENSOR / POTENSIOMETER
// =====================================================
void ADC_Init(void)
{
    // AVCC sebagai referensi, ADC0 default
    ADMUX = (1 << REFS0);

    // Enable ADC, prescaler 128
    // 16 MHz / 128 = 125 kHz
    ADCSRA = (1 << ADEN) |
             (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

uint16_t ADC_Read(uint8_t channel)
{
    ADMUX = (ADMUX & 0xE0) | (channel & 0x1F);

    ADCSRA |= (1 << ADSC);
    while (ADCSRA & (1 << ADSC));

    return ADC;
}

float bacaPH(void)
{
    uint16_t adcValue = ADC_Read(0);   // A0 = ADC0

    // Simulasi pH 0 - 14 seperti fungsi map Arduino
    float ph = ((float)adcValue * 14.0) / 1023.0;

    return ph;
}

// =====================================================
// TWI / I2C UNTUK RTC DS1307
// =====================================================
void TWI_Init(void)
{
    // SCL = 100 kHz
    // TWBR = ((F_CPU / SCL) - 16) / 2
    TWBR = 72;
    TWSR = 0x00;
}

void TWI_Start(void)
{
    TWCR = (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));
}

void TWI_Stop(void)
{
    TWCR = (1 << TWINT) | (1 << TWSTO) | (1 << TWEN);
}

void TWI_Write(uint8_t data)
{
    TWDR = data;
    TWCR = (1 << TWINT) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));
}

uint8_t TWI_Read_ACK(void)
{
    TWCR = (1 << TWINT) | (1 << TWEN) | (1 << TWEA);
    while (!(TWCR & (1 << TWINT)));
    return TWDR;
}

uint8_t TWI_Read_NACK(void)
{
    TWCR = (1 << TWINT) | (1 << TWEN);
    while (!(TWCR & (1 << TWINT)));
    return TWDR;
}

uint8_t bcdToDec(uint8_t val)
{
    return ((val >> 4) * 10) + (val & 0x0F);
}

uint8_t decToBcd(uint8_t val)
{
    return ((val / 10) << 4) | (val % 10);
}

void RTC_SetTime(uint8_t jam, uint8_t menit, uint8_t detik)
{
    TWI_Start();
    TWI_Write(DS1307_ADDR << 1);      // Write mode
    TWI_Write(0x00);                  // Register detik

    TWI_Write(decToBcd(detik) & 0x7F);
    TWI_Write(decToBcd(menit));
    TWI_Write(decToBcd(jam));

    TWI_Stop();
}

void RTC_ReadTime(uint8_t *jam, uint8_t *menit, uint8_t *detik)
{
    TWI_Start();
    TWI_Write(DS1307_ADDR << 1);      // Write mode
    TWI_Write(0x00);                  // Mulai dari register detik

    TWI_Start();
    TWI_Write((DS1307_ADDR << 1) | 1); // Read mode

    uint8_t rawDetik = TWI_Read_ACK();
    uint8_t rawMenit = TWI_Read_ACK();
    uint8_t rawJam   = TWI_Read_NACK();

    TWI_Stop();

    *detik = bcdToDec(rawDetik & 0x7F);
    *menit = bcdToDec(rawMenit);
    *jam   = bcdToDec(rawJam & 0x3F);
}

// =====================================================
// ONE WIRE UNTUK DS18B20
// =====================================================
void OneWire_Low(void)
{
    DS18B20_DDR |= (1 << DS18B20_PIN);
    DS18B20_PORT &= ~(1 << DS18B20_PIN);
}

void OneWire_Release(void)
{
    DS18B20_DDR &= ~(1 << DS18B20_PIN);
    DS18B20_PORT |= (1 << DS18B20_PIN);   // Pull-up internal
}

uint8_t OneWire_Reset(void)
{
    uint8_t presence;

    OneWire_Low();
    _delay_us(480);

    OneWire_Release();
    _delay_us(70);

    presence = !(DS18B20_PINR & (1 << DS18B20_PIN));

    _delay_us(410);

    return presence;
}

void OneWire_WriteBit(uint8_t bit)
{
    if (bit)
    {
        OneWire_Low();
        _delay_us(6);
        OneWire_Release();
        _delay_us(64);
    }
    else
    {
        OneWire_Low();
        _delay_us(60);
        OneWire_Release();
        _delay_us(10);
    }
}

uint8_t OneWire_ReadBit(void)
{
    uint8_t bit;

    OneWire_Low();
    _delay_us(6);

    OneWire_Release();
    _delay_us(9);

    bit = (DS18B20_PINR & (1 << DS18B20_PIN)) ? 1 : 0;

    _delay_us(55);

    return bit;
}

void OneWire_WriteByte(uint8_t data)
{
    for (uint8_t i = 0; i < 8; i++)
    {
        OneWire_WriteBit(data & 0x01);
        data >>= 1;
    }
}

uint8_t OneWire_ReadByte(void)
{
    uint8_t data = 0;

    for (uint8_t i = 0; i < 8; i++)
    {
        if (OneWire_ReadBit())
        {
            data |= (1 << i);
        }
    }

    return data;
}

float DS18B20_ReadTemperature(void)
{
    uint8_t tempL, tempH;
    int16_t rawTemp;

    if (!OneWire_Reset())
    {
        return -127.0;   // Sensor tidak terdeteksi
    }

    OneWire_WriteByte(0xCC);   // Skip ROM
    OneWire_WriteByte(0x44);   // Convert T

    delay_ms_var(750);

    if (!OneWire_Reset())
    {
        return -127.0;
    }

    OneWire_WriteByte(0xCC);   // Skip ROM
    OneWire_WriteByte(0xBE);   // Read Scratchpad

    tempL = OneWire_ReadByte();
    tempH = OneWire_ReadByte();

    rawTemp = (tempH << 8) | tempL;

    return (float)rawTemp / 16.0;
}

// =====================================================
// SERVO SOFTWARE PWM
// =====================================================
void Servo_Init(void)
{
    SERVO_DDR |= (1 << SERVO_PIN);
    SERVO_PORT &= ~(1 << SERVO_PIN);
}

void Servo_Write(uint8_t angle)
{
    uint16_t pulseWidth;

    // Konversi sudut 0 - 180 derajat ke pulsa 1000 - 2000 us
    pulseWidth = 1000 + ((uint32_t)angle * 1000) / 180;

    SERVO_PORT |= (1 << SERVO_PIN);
    delay_us_var(pulseWidth);

    SERVO_PORT &= ~(1 << SERVO_PIN);
    delay_us_var(20000 - pulseWidth);
}

void Servo_Hold(uint8_t angle, uint16_t duration_ms)
{
    uint16_t cycle = duration_ms / 20;

    for (uint16_t i = 0; i < cycle; i++)
    {
        Servo_Write(angle);
    }
}

// =====================================================
// FUNGSI BERI PAKAN
// =====================================================
void beriPakan(void)
{
    UART0_SendString("Memberi pakan ikan...\r\n");

    Servo_Hold(90, 1500);   // Servo membuka wadah pakan
    Servo_Hold(0, 1000);    // Servo menutup kembali

    UART0_SendString("Pakan selesai diberikan.\r\n");
}

// =====================================================
// PRINT WAKTU
// =====================================================
void printTwoDigit(uint8_t data)
{
    if (data < 10)
    {
        UART0_SendChar('0');
    }

    UART0_SendInt(data);
}

// =====================================================
// MAIN PROGRAM
// =====================================================
int main(void)
{
    float suhuAir;
    float nilaiPH;

    uint8_t jam, menit, detik;

    UART0_Init(9600);
    ADC_Init();
    TWI_Init();
    Servo_Init();

    OneWire_Release();

    Servo_Hold(0, 500);

    UART0_SendString("Sistem Monitoring dan Pemberi Pakan Ikan Otomatis\r\n");
    UART0_SendString("==================================================\r\n");

    while (1)
    {
        RTC_ReadTime(&jam, &menit, &detik);

        suhuAir = DS18B20_ReadTemperature();
        nilaiPH = bacaPH();

        UART0_SendString("Waktu: ");
        printTwoDigit(jam);
        UART0_SendChar(':');
        printTwoDigit(menit);
        UART0_SendChar(':');
        printTwoDigit(detik);

        UART0_SendString(" | Suhu: ");
        UART0_SendFloat(suhuAir, 5, 2);
        UART0_SendString(" C");

        UART0_SendString(" | pH: ");
        UART0_SendFloat(nilaiPH, 4, 2);

        if (suhuAir < 24.0)
        {
            UART0_SendString(" | Status Suhu: Dingin");
        }
        else if (suhuAir <= 30.0)
        {
            UART0_SendString(" | Status Suhu: Normal");
        }
        else
        {
            UART0_SendString(" | Status Suhu: Panas");
        }

        if (nilaiPH < 6.5)
        {
            UART0_SendString(" | Status pH: Asam");
        }
        else if (nilaiPH <= 8.0)
        {
            UART0_SendString(" | Status pH: Normal");
        }
        else
        {
            UART0_SendString(" | Status pH: Basa");
        }

        UART0_SendString("\r\n");

        // Jadwal pakan pertama
        if (jam == jamPakan1 && menit == menitPakan1 && sudahPakan1 == 0)
        {
            beriPakan();
            sudahPakan1 = 1;
        }

        // Jadwal pakan kedua
        if (jam == jamPakan2 && menit == menitPakan2 && sudahPakan2 == 0)
        {
            beriPakan();
            sudahPakan2 = 1;
        }

        // Reset status pakan setiap pergantian hari
        if (jam == 0 && menit == 0)
        {
            sudahPakan1 = 0;
            sudahPakan2 = 0;
        }

        delay_ms_var(1000);
    }
}