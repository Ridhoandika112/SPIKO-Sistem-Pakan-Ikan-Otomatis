#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <RTClib.h>
#include <Servo.h>

// ================= PIN CONFIG =================
#define ONE_WIRE_BUS 22     // DS18B20 DQ ke pin D22
#define PH_PIN A0           // Potensiometer pH ke A0
#define SERVO_PIN 9         // Servo ke PWM D9

// ================= OBJECT =================
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature suhuSensor(&oneWire);
RTC_DS1307 rtc;
Servo servoPakan;

// ================= VARIABEL =================
float suhuAir;
float nilaiPH;

int jamPakan1 = 12;      // Jadwal pakan pertama: 07:00
int menitPakan1 = 40;

int jamPakan2 = 17;     // Jadwal pakan kedua: 17:00
int menitPakan2 = 0;

bool sudahPakan1 = false;
bool sudahPakan2 = false;

// ================= FUNGSI BACA PH =================
float bacaPH()
{
  int adcValue = analogRead(PH_PIN);

  // Tegangan dari potensiometer
  float voltage = adcValue * (5.0 / 1023.0);

  // Simulasi nilai pH dari 0 - 14
  float ph = map(adcValue, 0, 1023, 0, 1400) / 100.0;

  return ph;
}

// ================= FUNGSI BERI PAKAN =================
void beriPakan()
{
  Serial.println("Memberi pakan ikan...");

  servoPakan.write(90);     // Servo membuka wadah pakan
  delay(1500);

  servoPakan.write(0);      // Servo menutup kembali
  delay(1000);

  Serial.println("Pakan selesai diberikan.");
}

// ================= SETUP =================
void setup()
{
  Serial.begin(9600);

  suhuSensor.begin();
  Wire.begin();

  servoPakan.attach(SERVO_PIN);
  servoPakan.write(0);

  if (!rtc.begin())
  {
    Serial.println("RTC DS1307 tidak terdeteksi!");
    while (1);
  }

  if (!rtc.isrunning())
  {
    Serial.println("RTC belum berjalan, mengatur waktu awal...");

    // Atur waktu RTC sesuai waktu upload program
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }

  Serial.println("Sistem Monitoring dan Pemberi Pakan Ikan Otomatis");
  Serial.println("==================================================");
}

// ================= LOOP =================
void loop()
{
  DateTime now = rtc.now();

  // Baca suhu DS18B20
  suhuSensor.requestTemperatures();
  suhuAir = suhuSensor.getTempCByIndex(0);

  // Baca pH dari potensiometer
  nilaiPH = bacaPH();

  // Tampilkan data ke Serial Monitor
  Serial.print("Waktu: ");
  if (now.hour() < 10) Serial.print("0");
  Serial.print(now.hour());
  Serial.print(":");
  if (now.minute() < 10) Serial.print("0");
  Serial.print(now.minute());
  Serial.print(":");
  if (now.second() < 10) Serial.print("0");
  Serial.print(now.second());

  Serial.print(" | Suhu: ");
  Serial.print(suhuAir);
  Serial.print(" C");

  Serial.print(" | pH: ");
  Serial.print(nilaiPH);

  // Status kondisi air
  if (suhuAir < 24)
  {
    Serial.print(" | Status Suhu: Dingin");
  }
  else if (suhuAir <= 30)
  {
    Serial.print(" | Status Suhu: Normal");
  }
  else
  {
    Serial.print(" | Status Suhu: Panas");
  }

  if (nilaiPH < 6.5)
  {
    Serial.print(" | Status pH: Asam");
  }
  else if (nilaiPH <= 8.0)
  {
    Serial.print(" | Status pH: Normal");
  }
  else
  {
    Serial.print(" | Status pH: Basa");
  }

  Serial.println();

  // ================= LOGIKA JADWAL PAKAN =================

  // Jadwal pakan pertama
  if (now.hour() == jamPakan1 && now.minute() == menitPakan1 && sudahPakan1 == false)
  {
    beriPakan();
    sudahPakan1 = true;
  }

  // Jadwal pakan kedua
  if (now.hour() == jamPakan2 && now.minute() == menitPakan2 && sudahPakan2 == false)
  {
    beriPakan();
    sudahPakan2 = true;
  }

  // Reset status pakan setiap pergantian hari
  if (now.hour() == 0 && now.minute() == 0)
  {
    sudahPakan1 = false;
    sudahPakan2 = false;
  }

  delay(1000);
}